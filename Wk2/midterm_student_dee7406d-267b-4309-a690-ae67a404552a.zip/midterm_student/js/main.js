/*
    Mid Terms for PWA1
    do NOT modify the included HTML/CSS file
    read comments in HTML
    Make sure the first student's information is displayed when the browser loads
*/

(function(){

	
	
})();  // end self executing closure