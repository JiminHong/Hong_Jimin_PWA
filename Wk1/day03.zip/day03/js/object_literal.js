
//Data structures and control structures
//Control structures: conditionals, and loops

var notSoCoolDog = ["pit bull","black","Max",7];
var coolDog = {breed:"Pitbull",color:"black",name:"Max",age:7};

var cat = {};
cat.name = "fido";
cat.age = "3";
//coolDog.legs = true;  // adds property

console.log(notSoCoolDog[1],[1]);
console.log(coolDog.color); // dot syntax
console.log(coolDog["name"]); // access notation





